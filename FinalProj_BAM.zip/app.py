import os
import pandas as pd
import plotly.express as px

from flask import Flask
from flask import request
from flask import render_template_string

from preprocessing import (
    clean_currency,
    clean_data
)

from training import (
    train_classifier,
    train_regressor
)

from prediction import (
    predict_buy,
    predict_sales
)

app = Flask(__name__)

RAW = "https://raw.githubusercontent.com/apcyssr/AdventureSale/main/"


def load(name):
    return pd.read_csv(RAW + name)


def build_data():

    sales = load("Sales_data.csv")
    order = load("Sales_Order_data.csv")
    product = load("Product_data.csv")
    customer = load("Customer_data.csv")
    territory = load("Sales_Territory_data.csv")
    date = load("Date_data.csv")

    sales = clean_currency(sales)
    product = clean_currency(product)

    df = (
        sales
        .merge(order, on="SalesOrderLineKey")
        .merge(product, on="ProductKey")
        .merge(customer, on="CustomerKey")
        .merge(territory, on="SalesTerritoryKey")
        .merge(
            date,
            left_on="OrderDateKey",
            right_on="DateKey"
        )
    )

    df = clean_data(df)

    return df


@app.route("/", methods=["GET", "POST"])
def dashboard():

    df = build_data()

    clf, acc, clf_cols = train_classifier(df)

    reg, mae, rmse, reg_cols = train_regressor(df)

    total_sales = df["Sales Amount"].sum()

    total_customers = (
        df["CustomerKey"]
        .nunique()
    )

    total_products = (
        df["ProductKey"]
        .nunique()
    )

    country_sales = (
        df.groupby("Country")
        ["Sales Amount"]
        .sum()
        .reset_index()
        .sort_values(
            "Sales Amount",
            ascending=False
        )
        .head(10)
    )

    category_sales = (
        df.groupby("Category")
        ["Sales Amount"]
        .sum()
        .reset_index()
        .sort_values(
            "Sales Amount",
            ascending=False
        )
        .head(10)
    )

    yearly_sales = (
        df.groupby("Fiscal Year")
        ["Sales Amount"]
        .sum()
        .reset_index()
    )

    segment = (
        df.groupby("CustomerKey")
        ["Sales Amount"]
        .sum()
        .reset_index()
    )

    q1 = segment["Sales Amount"].quantile(0.25)
    q3 = segment["Sales Amount"].quantile(0.75)

    segment["Segment"] = segment["Sales Amount"].apply(
        lambda x:
        "VIP" if x >= q3
        else "Regular" if x >= q1
        else "Low Value"
    )

    segment_chart = (
        segment["Segment"]
        .value_counts()
        .reset_index()
    )

    fig1 = px.bar(
        country_sales,
        x="Country",
        y="Sales Amount",
        title="Top Revenue Countries"
    )

    fig2 = px.bar(
        category_sales,
        x="Category",
        y="Sales Amount",
        title="Top Product Categories"
    )

    fig3 = px.line(
        yearly_sales,
        x="Fiscal Year",
        y="Sales Amount",
        markers=True,
        title="Revenue Trend"
    )

    fig4 = px.pie(
        segment_chart,
        names="Segment",
        values="count",
        title="CRM Customer Segments"
    )

    buy_prediction = ""
    sales_prediction = ""
    recommendation = ""

    if request.method == "POST":

        action = request.form.get("action")

        if action == "buy":

            buy_prediction = predict_buy(
                clf,
                clf_cols,
                request.form["country"]
            )

        if action == "sales":

            sales_prediction = round(
                predict_sales(
                    reg,
                    reg_cols,
                    request.form["country"],
                    request.form["category"],
                    float(request.form["price"]),
                    int(request.form["qty"])
                ),
                2
            )

            if sales_prediction > 10000:
                recommendation = (
                    "Premium Campaign Recommended"
                )
            else:
                recommendation = (
                    "Discount Campaign Recommended"
                )
    

    html = """
    <html>

    <head>

    <title>
    AdventureWorks CRM Dashboard
    </title>

    <style>

    body{
        font-family:Segoe UI;
        background:#f5f7fb;
        margin:0;
    }

    header{
        background:#0f172a;
        color:white;
        text-align:center;
        padding:25px;
    }

    .container{
        max-width:1400px;
        margin:auto;
        padding:20px;
    }

    .grid{
        display:grid;
        grid-template-columns:
        repeat(auto-fit,minmax(250px,1fr));
        gap:15px;
    }

    .card{
        background:white;
        padding:18px;
        border-radius:12px;
        box-shadow:0 2px 8px rgba(0,0,0,.1);
        margin-bottom:20px;
    }

    .metric{
        font-size:30px;
        font-weight:bold;
    }

    input,button{
        padding:10px;
        margin:5px;
    }

    </style>

    </head>

    <body>

    <header>

    <h1>
    AdventureWorks CRM Analytics Dashboard
    </h1>

    <p>
    EDA • CRM Discovery • Random Forest
    </p>

    </header>

    <div class="container">

    <div class="grid">

    <div class="card">
    <h3>Total Sales</h3>
    <div class="metric">
    ${:,.0f}
    </div>
    </div>

    <div class="card">
    <h3>Customers</h3>
    <div class="metric">
    {:,}
    </div>
    </div>

    <div class="card">
    <h3>Products</h3>
    <div class="metric">
    {:,}
    </div>
    </div>

    <div class="card">
    <h3>Classifier Accuracy</h3>
    <div class="metric">
    {:.2f}%
    </div>
    </div>

    </div>

    <div class="card">{}</div>

    <div class="card">{}</div>

    <div class="card">{}</div>

    <div class="card">{}</div>

    <div class="grid">

    <div class="card">

    <h2>Buy / Not Buy Prediction</h2>

    <form method="POST">

    <input
    name="country"
    placeholder="Country">

    <button
    name="action"
    value="buy">

    Predict

    </button>

    </form>

    <h3>{}</h3>

    </div>

    <div class="card">

    <h2>Sales Prediction</h2>

    <form method="POST">

    <input
    name="country"
    placeholder="Country">

    <input
    name="category"
    placeholder="Category">

    <input
    name="price"
    placeholder="List Price">

    <input
    name="qty"
    placeholder="Quantity">

    <button
    name="action"
    value="sales">

    Predict

    </button>

    </form>

    <h3>
    ${}
    </h3>

    <p>
    {}
    </p>

    </div>

    </div>

    <div class="card">

    <h2>Model Evaluation</h2>

    <p>
    Accuracy : {:.2f}%
    </p>

    <p>
    MAE : {:.2f}
    </p>

    <p>
    RMSE : {:.2f}
    </p>

    </div>

    </div>

    </body>

    </html>
    """.format(
        total_sales,
        total_customers,
        total_products,
        acc * 100,
        fig1.to_html(full_html=False),
        fig2.to_html(full_html=False),
        fig3.to_html(full_html=False),
        fig4.to_html(full_html=False),
        buy_prediction,
        sales_prediction,
        recommendation,
        acc * 100,
        mae,
        rmse
    )

    return html
    




if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )

